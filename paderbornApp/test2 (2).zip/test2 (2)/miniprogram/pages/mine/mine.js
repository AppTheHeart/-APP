//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
  },

  gorecharge:function(){
    wx.navigateTo({
      url: '../repair_record/repair_record',
    })
  },
  gobuyrecord:function(){
    wx.navigateTo({
      url: '../repair_record/repair_record',
    })
  }
})

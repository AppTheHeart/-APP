// index.js
// 获取应用实例
var util = require('../../utils/util.js')
const app = getApp()

Page({
  data: {
	allParams: [{
		text: '径向力',
		value: 'force'
	},
	{
		text: '第一相电流',
		value: 'phase_current_1'
	},
	{
		text: '第二相电流',
		value: 'phase_current_2'
	},
	{
		text: '旋转速率',
		value: 'speed'
	},
	{
		text: '负荷扭矩',
		value: 'torque'
	},
	{
		text: '振动信号',
		value: 'vibration_1'
	}
	],
	zcnum: ['paderborn1','paderborn2','paderborn3','paderborn4',
			'paderborn5','paderborn6','paderborn7','paderborn8',
			'paderborn9','paderborn10','paderborn11','paderborn12'],
	device: ['1_M01_F10','2_M01_F10','3_M01_F10','4_M01_F10',
			 '5_M07_F04','6_M07_F04','7_M07_F04','8_M07_F04',
			 '9_M07_F10','10_M07_F10','11_M07_F10','12_M07_F10'],
	test_csv: '_test.csv',
  result: [],
  predict: [],
    out_file_name: '',
    
    
  },

  onLoad() {
  
  },
  
  getSingleParamData: function (dev_id, attr, callback){
	  var that =this
	  wx.request({
		  url: 'https://phmlearn.com/component/data/paderborn',
		  method: 'POST',
		  header: {"Content-Type": "application/x-www-form-urlencoded"},
		  data: {
			  device_id: dev_id,
			  attribute: attr,
			  access_token: getApp().globalData.access_token
		  },
		  success: function (res) {
			  callback(res)
		  }
	  })
  },
  
  getAllParamsDatas: function (dev_id) {
	  const allParamsName = this.data.allParams
	  let promise = []
	  for (let i = 0; i < allParamsName.length; i++) {
		  let paramsKey = allParamsName[i].value
		  if (i === 0){
			  this.getSingleParamData(dev_id,paramsKey,res=>{
				  this.getC(res.data.data[paramsKey])
			  })
		  }
		
		  promise.push(this.getSingleParamData(dev_id, paramsKey, res=>{
			  const data = res.data.data[paramsKey]
			  this.setData({
				  [`result[${i}]`]: {
					  key: allParamsName[i].text,
					  max: util.getMaxValue(data),
					  min: util.getMinValue(data),
					  arr: util.getDataArray(data)
				  }
			  })
		  }))
	  }
	  Promise.all(promise).then(res=>{
		  
	  })
  },

  getC: function (array) {
    console.log(array.length)
  },





  dataGet: function(){
    let devs = this.data.device
    this.getAllParamsDatas(devs[0])
    this.try2(devs[0]+this.data.test_csv)
    
  },

  try2: function(dev){
    var that = this
    wx.request({
      url: 'https://phmlearn.com/component/upload/2/319',
      method:'POST',
      header:{"Content-Type": "application/x-www-form-urlencoded"},
      data:{
        access_token: getApp().globalData.access_token,
        file_name: dev//'testdatashuffle_2_demo.csv'
      },
      success: function (res){
        console.log(res.data)
        that.setData({
          out_file_name: res.data.data.file_name
        })
      }
    })
  },

  try3: function(){
    var that = this
    console.log(that.data.out_file_name)
    wx.request({
      url: 'https://phmlearn.com/component/upload/2/377',
      method:'POST',
      header:{"Content-Type": "application/x-www-form-urlencoded"},
      data:{
        access_token: getApp().globalData.access_token,
        file_name: that.data.out_file_name
      },
      success: function (res){
        console.log(res.data)
        that.setData({
          out_file_name: res.data.data.file_name
        })
      }
    })
  },

  try4: function(){
    var that = this
    console.log(that.data.out_file_name)
    wx.request({
      url: 'https://phmlearn.com/component/upload/ML/model/169/385',
      method:'POST',
      header:{"Content-Type": "application/x-www-form-urlencoded"},
      data:{
        access_token: getApp().globalData.access_token,
        file_name: that.data.out_file_name
      },
      success: function (res){
        console.log(res.data)
        that.setData({
          predict: res.data.data.predict
        })
      }
    })
  }
})

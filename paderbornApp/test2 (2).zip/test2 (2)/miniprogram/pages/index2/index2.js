// index.js
// 获取应用实例
var util = require('../../utils/util.js')
const app = getApp()
import * as echarts from '../../ec-canvas/echarts';
var initChart = null

function setOption(chart, xlist, ylist) {
  var options = {
    title: {
      left: 'center'
    },
    color: ["#37A2DA"],
    grid: {
      top: 20,
      right: 20,
      bottom: 30
    },
    tooltip: {
      show: true,
      trigger: 'axis'
    },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: xlist//['6s前', '5s前', '4s前', '3s前', '2s前', '1s前']
    },
    yAxis: {
      x: 'center',
      type: 'value',
      splitLine: {
        lineStyle: {
          type: 'dashed'
        }
      },
      scale : true
    },
    series: [{
      type: 'line',
      smooth: true,
      data: ylist
    }],
    dataZoom: [{
      type: 'slider',
      show: true,
      startValue: xlist.length-2559,
      endValue: xlist.length,
      handleSize: '30%'
    },
    {
      type: 'inside',
      start: 0,
      end: 30
    }
  ],
  }
  chart.setOption(options);
}

Page({
  data: {
	allParams: [{
		text: '径向力',
		value: 'force'
	},
	{
		text: '第一相电流',
		value: 'phase_current_1'
	},
	{
		text: '第二相电流',
		value: 'phase_current_2'
	},
	{
		text: '旋转速率',
		value: 'speed'
	},
	{
		text: '负荷扭矩',
		value: 'torque'
	},
	{
		text: '振动信号',
		value: 'vibration_1'
	}
	],
	zcnum: ['paderborn1','paderborn2','paderborn3','paderborn4',
			'paderborn5','paderborn6','paderborn7','paderborn8',
			'paderborn9','paderborn10','paderborn11','paderborn12'],
	device: ['1_M01_F10','2_M01_F10','3_M01_F10','4_M01_F10',
			 '5_M07_F04','6_M07_F04','7_M07_F04','8_M07_F04',
			 '9_M07_F10','10_M07_F10','11_M07_F10','12_M07_F10'],
  test_csv: '_test.csv',
  allConditionName:['径向力','第一相电流','第二相电流','旋转速率','负荷扭矩','振动信号'],
  index:0,
  index2:0,
  i:0,
  time:'',
  timer: '',
  timer2: '',
  result: [],
  predict: [],
  chartTimer: '',
  ec: {
    lazyLoad: true
  }  
    
  },

  onLoad:function() {
    this.setData({
      time: util.formatTime(new Date()),
      
    }),
    this.oneComponent = this.selectComponent('#mychart-dom-line');  //和数据表格显示有关
    this.dataGet()
  },
  
  getSingleParamData: function (dev_id, attr, callback){
	  var that =this
	  wx.request({
		  url: 'https://phmlearn.com/component/data/paderborn',
		  method: 'POST',
		  header: {"Content-Type": "application/x-www-form-urlencoded"},
		  data: {
			  device_id: dev_id,
			  attribute: attr,
			  access_token: getApp().globalData.access_token
		  },
		  success: function (res) {
			  callback(res)
		  }
	  })
  },
  
  getAllParamsDatas: function (dev_id) {
	  const allParamsName = this.data.allParams
	  let promise = []
	  for (let i = 0; i < allParamsName.length; i++) {
		  let paramsKey = allParamsName[i].value
		  if (i === 0){
			  this.getSingleParamData(dev_id,paramsKey,res=>{
				  this.getC(res.data.data[paramsKey])
			  })
		  }
		  promise.push(this.getSingleParamData(dev_id, paramsKey, res=>{
			  const data = res.data.data[paramsKey]
			  this.setData({
				  [`result[${i}]`]: {
					  key: allParamsName[i].text,
					  max: util.getMaxValue(data),
					  min: util.getMinValue(data),
            arr: util.getDataArray(data),
				  }
			  })
		  }))
	  }
	  Promise.all(promise).then(res=>{
      this.startTimer();
      this.setDateTime();
	  })
  },

  getChartdata: function (array) {
    var that = this
    wx.showLoading({
      title: '折线图加载中',
    })
    if (this.data.chartTimer) {
      this.closeTimer(this.data.chartTimer)
    }
    let index = 2560
    this.setData({
      chartTimer: setInterval(() => {
        
        if (index <= 8832) {
          this.setData({
            ylist: array.slice(0, index),
            xAxis: that.data.xaix.slice(0,index)
          })
          index = index + 128
        } else {
          this.closeTimer(this.data.chartTimer)
          this.setData({
            ylist: array.slice(0, array.length - 1),
            xAxis: array.slice(0, array.length - 1),
          })
        }

        this.oneComponent.init((canvas, width, height) => {
          const chart = echarts.init(canvas, null, {
            width: width,
            height: height
          });
          setOption(chart, this.data.xAxis, this.data.ylist) //赋值给echart图表
          this.chart = chart;
          wx.hideLoading()
          return chart;
        });

      }, 2000)
    })
  },
  getC: function (array) {
    console.log(array.length)
    var xaix = []
    for (let i = 0; i < 8832; i++) {
		  xaix[i]=i
      }
      this.setData({
        xaix : xaix
      })
  },


  dataGet: function(){
    let devs = this.data.device
    this.getAllParamsDatas(devs[0])
    this.try2(devs[0]+this.data.test_csv)
    
  },

  
  try2: function(dev){
    var that = this
    wx.request({
      url: 'https://phmlearn.com/component/upload/2/319',
      method:'POST',
      header:{"Content-Type": "application/x-www-form-urlencoded"},
      data:{
        access_token: getApp().globalData.access_token,
        file_name: dev//'testdatashuffle_2_demo.csv'
      },
      success: function (res){
        console.log(res.data)
        let filename = res.data.data.file_name
        console.log(filename)
        that.try3(filename)
      }
    })
  },
  try3: function(filename){
    var that = this
    console.log(filename)
    wx.request({
      url: 'https://phmlearn.com/component/upload/2/377',
      method:'POST',
      header:{"Content-Type": "application/x-www-form-urlencoded"},
      data:{
        access_token: getApp().globalData.access_token,
        file_name: filename
      },
      success: function (res){
        console.log(res.data)
        let filename = res.data.data.file_name
        that.try4(filename)
      }
    })
  },
  try4: function(filename){
    var that = this
    //console.log(filename)
    wx.request({
      url: 'https://phmlearn.com/component/upload/ML/model/169/385',
      method:'POST',
      header:{"Content-Type": "application/x-www-form-urlencoded"},
      data:{
        access_token: getApp().globalData.access_token,
        file_name: filename
      },
      success: function (res){
        console.log(res.data)
        that.setData({
          predict: res.data.data.predict
        })
        let arr = that.data.result[0].arr
        that.getChartdata(arr)
      }
    })
  },

  setDateTime: function () {
    this.setData({
      timer2: setInterval(() => {
        this.setData({
          time: util.formatTime(new Date())
        })
      }, 1000)
    })
  },
    //开启刷新数据定时器
    startTimer: function () {
      this.setData({
        i: 0
      })
      this.setData({
        timer: setInterval(() => {
          if (this.data.i <= 8832) {
            this.setData({
              i: this.data.i + 1
            })
          } else {
            this.setData({
              i: 0
            })
            this.closeTimer(this.data.timer)
            this.closeTimer(this.data.timer2)
          }
        }, 1000)
      })
    },
    //关闭定时器
    closeTimer: function (time) {
      clearInterval(time)
    },
//设备切到几，devs[i]切到几
    bindPickerChange: function (e) {
      //let arr = device
      //this.closeTimer(this.data.timer)
      //this.closeTimer(this.data.timer2)
      this.setData({
        index: e.detail.value
      })
      let j = this.data.index
      let devs = this.data.device
      this.getAllParamsDatas(devs[j])
      this.try2(devs[j]+this.data.test_csv)
    },
    //切换工况picker
  bindPickerChange2: function (e) {
    this.setData({
      index2: e.detail.value  //修改的是wxml里的显示，allParams[index2].text
    })
    let index = e.detail.value
    let arr = this.data.result[index].arr //??? arr是什么，result是什么
    this.getChartdata(arr)
  },
//页面卸载时清空定时器
onUnload: function () {
  if (this.data.timer) {
    this.closeTimer(this.data.timer)
  }
  if (this.data.timer2) {
    this.closeTimer(this.data.timer2)
  }
  if (this.data.chartTimer) {
    this.closeTimer(this.data.chartTimer)
  }
}
})






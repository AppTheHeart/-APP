// pages/work_list/work_list.js
var util = require('../../utils/util.js')
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tabindex:1,
    contentActive:1,
    boxdata :[],
    boxdata1: [
      { date: '2021-04-25',product: '故障一',  order: 'FDD25454545', remark: '故障备注'}
    ],
    boxdata2: [
      { date: '2021-04-10',  parts: '转轴部件', remark: '这是问题描述显示', order: 'FDD25454545' }
    ],
    boxdata3: [
      { type: '2', date: '2021-03-15', parts: '转轴部件', remark: '这是问题描述显示', order: 'FDD25454545' },        { type: '2', date: '2021-02-15', parts: '转轴部件', remark: '这是问题描述显示',  order: 'FDD25454545' }
    ]
  },
  tapchange:function(event){
    var index = event.currentTarget.dataset.index;
    this.setData({
      tabindex: index,
      contentActive:index,
    })
  },
  calltel:function(event){
    var tel = event.currentTarget.dataset.tel;
    var num1=event.currentTarget.dataset.num;
    wx.makePhoneCall({
      phoneNumber: tel
    }),
     this.data.boxdata[num1][4]=1
     this.setData(
       {
        boxdata: this.data.boxdata
      }
    )
  },
  go_oveWork:function(event){
    var num2=event.currentTarget.dataset.num;
    this.data.boxdata[num2][4]=2
    this.data.boxdata[num2][5]=util.formatTime(new Date()),
    this.setData(
      {
       boxdata: this.data.boxdata
     }
   )
    // wx.navigateTo({
    //   url: '../over_work/over_work',
    // })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) 
  {
  
      this.setData({
       boxdata : app.globalData.todata
      })
    
  },

 
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
})
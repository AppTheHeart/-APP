//index.js
//获取应用实例
var util = require('../../utils/util.js')
const app = getApp()

Page({
  data: {
	    array: ['请选择部件', '1_M01_F10','2_M01_F10','3_M01_F10','4_M01_F10',
      '5_M07_F04','6_M07_F04','7_M07_F04','8_M07_F04',
      '9_M07_F10','10_M07_F10','11_M07_F10','12_M07_F10'],
      index: 0,
      miaoshudes:''
  },
  bindPickerChange:function(e){
    this.setData({
      index: e.detail.value
    })
  },
  gorepairrecode:function(){
    wx.navigateTo({
      url: '../repair_record/repair_record',
    })
  },
  Submit: function () {
    var that = this
    wx.showLoading({
      title: '上传成功',
    duration: 500}),
    app.globalData.repairtime[app.globalData.repairindex]= util.formatTime(new Date()),
    app.globalData.repairpartname[app.globalData.repairindex]= that.data.array[that.data.index],
    app.globalData.repairpartdes[app.globalData.repairindex]= that.data.miaoshudes

    app.globalData.todata[app.globalData.repairindex]=[app.globalData.repairindex,app.globalData.repairtime[app.globalData.repairindex],app.globalData.repairpartname[app.globalData.repairindex],app.globalData.repairpartdes[app.globalData.repairindex],0,0]

    app.globalData.repairindex ++,
    console.log(app.globalData.repairtime)
    console.log(app.globalData.repairindex)
    console.log(app.globalData.repairpartname)
    console.log(app.globalData.repairpartdes)

    console.log(app.globalData.todata)
    that.setData({
      index :0,
      miaoshudes : '',
      todata : app.globalData.todata
    })
  },
  miaoshu: function (e) {
    this.setData({
      miaoshudes : e.detail.value
    })
  }
})
